/************************** LOADER EN LA WEB **************************/
window.addEventListener('load', function(){
  const loadcli = document.querySelector('#cont-loader');
  loadcli.className += ' hidden';
})