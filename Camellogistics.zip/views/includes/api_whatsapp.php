<?php 
	$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
  $url =  $actual_link . "/Camellogistics/views/";
?>
<a href="https://api.whatsapp.com/send?phone=51951488317&text=Hola,%20quisiera%20m%C3%A1s%20informaci%C3%B3n%20sobre%20la%20plataforma." class="float" target="_blank" id="chat_wstp-icon">
	<div class="float--contText">
		<span>Asesor en Línea</span>
	</div>
	<div class="float--contIconWps">
		<img src="<?php echo $url; ?>assets/img/icons/whatsapp_api.svg" alt="">
	</div>
</a>