<?php
// if(isset($_POST)){
// 	print_r($_POST);
// }else{
// 	echo "Error al recibir los datos";
// }